"""Build the e-book PDF.

- Reads chapter Markdown files listed in CHAPTERS.
- Executes every ```python block that is followed by an empty ```output block,
  and fills the output with the REAL result (so every printed output is verified).
- Moves each chapter's '## Answers' section into the Answer Key at the back.
- Renders HTML with WeasyPrint (A4, running headers, page numbers, TOC page refs).
"""
import ast, contextlib, io, re, traceback, html, pathlib, datetime
import markdown
from weasyprint import HTML

ROOT = pathlib.Path(__file__).parent
CH = ROOT / "chapters"

CHAPTERS = [
    ("01", "Part 1: Understanding Data Analytics", "Introduction to Data Analytics"),
    ("02", None, "Understanding Data and Datasets"),
    ("03", "Part 2: Getting Started with Python", "Setting Up Your Learning Environment"),
    ("04", None, "Python Fundamentals"),
    ("05", None, "Lists, Dictionaries, Conditions, and Loops"),
    ("06", None, "Functions, Errors, and Writing Better Code"),
    ("07", "Part 3: Working with Data", "Introduction to NumPy"),
    ("08", None, "Introduction to Pandas"),
    ("09", None, "Loading and Exploring Real Datasets"),
    ("10", None, "Data Cleaning with Pandas"),
    ("11", None, "Data Analysis and Business Questions"),
    ("12", None, "Data Visualisation"),
    ("13", None, "Basic Statistics for Data Analysts"),
    ("14", "Part 4: Real-World Projects", "Project 1 — Sales Data Analysis"),
    ("15", None, "Project 2 — Student Performance Analysis"),
    ("16", None, "Project 3 — Customer and E-commerce Analysis"),
    ("17", None, "Final Capstone Project"),
    ("18", None, "Becoming a Job-Ready Beginner"),
]

# The book loads data from the author's GitHub repo. During the build, map that URL to local files.
DATA_URL = "https://raw.githubusercontent.com/Saurabh050794/learn-data-analytics-python/main/data/"
import pandas as _pd, os as _os
_orig_csv, _orig_xl = _pd.read_csv, _pd.read_excel
def _local(path):
    if not (isinstance(path, str) and path.startswith(DATA_URL)):
        return path
    name = path[len(DATA_URL):]
    made = ROOT / "work" / name          # files the book's own code created (e.g. Chapter 10)
    return str(made if made.exists() else ROOT / "data" / name)
_pd.read_csv = lambda path, *a, **k: _orig_csv(_local(path), *a, **k)
_pd.read_excel = lambda path, *a, **k: _orig_xl(_local(path), *a, **k)
_pd.set_option("display.width", 88); _pd.set_option("display.max_columns", 20)
(ROOT / "work").mkdir(exist_ok=True); _os.chdir(ROOT / "work")

FENCE = re.compile(r"```python\n(.*?)```\n\n```output\n```", re.S)


import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as _plt
FIG_DIR = ROOT / "figs"; FIG_DIR.mkdir(exist_ok=True)
_fig_count = [0]

def _grab_figures():
    """Save any open matplotlib figures (as Colab would display them) and return <img> tags."""
    tags = []
    for num in _plt.get_fignums():
        fig = _plt.figure(num)
        _fig_count[0] += 1
        path = FIG_DIR / f"fig{_fig_count[0]:03d}.png"
        fig.savefig(path, dpi=200, bbox_inches="tight")
        tags.append(f'<img class="chart" src="{path}">')
    _plt.close("all")
    return tags

def run_block(code, ns):
    """Run code like a Colab cell: print output + repr of a final expression."""
    buf = io.StringIO()
    try:
        tree = ast.parse(code)
        last = None
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            last = ast.Expression(tree.body.pop().value)
        with contextlib.redirect_stdout(buf):
            exec(compile(tree, "<cell>", "exec"), ns)
            if last is not None:
                val = eval(compile(last, "<cell>", "eval"), ns)
                if val is not None:
                    print(repr(val))
    except Exception as e:  # show the final error line, like the bottom of a traceback
        out = buf.getvalue()
        msg = e.msg if isinstance(e, SyntaxError) else str(e)
        return out + f"{type(e).__name__}: {msg}", True
    return buf.getvalue().rstrip("\n"), False


def execute_chapter(text, log):
    ns = {}
    def repl(m):
        code = m.group(1)
        out, err = run_block(code, ns)
        figs = _grab_figures()
        log.append((err, code.splitlines()[0] if code.strip() else "", out.splitlines()[-1:] ))
        if figs and not out.strip():
            return (f"```python\n{code}```\n\n<div class=\"out\"><div class=\"out-label\">Output</div>"
                    + "".join(figs) + "</div>\n")
        if not out.strip():
            out = "(no output - this is normal)"
        cls, lab = ("out err", "Error message") if err else ("out", "Output")
        return (f"```python\n{code}```\n\n<div class=\"{cls}\"><div class=\"out-label\">{lab}</div>"
                f"<pre>{html.escape(out)}</pre>" + "".join(figs) + "</div>\n")
    return FENCE.sub(repl, text)


def md_to_html(text):
    md = markdown.Markdown(extensions=["tables", "fenced_code", "codehilite", "admonition", "attr_list", "sane_lists", "md_in_html"],
                           extension_configs={"codehilite": {"guess_lang": False, "css_class": "code"}})
    h = md.convert(text)
    # label output blocks
    h = h.replace('<div class="code"><pre><span></span><code>', '<div class="code"><pre><code>')
    return h


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def build():
    log = []
    parts_html, answers_html, toc = [], [], []
    for num, part, title in CHAPTERS:
        raw = (CH / f"ch{num}.md").read_text()
        raw = execute_chapter(raw, log)
        body, _, ans = raw.partition("\n## Answers\n")
        cid = f"ch{num}"
        if part:
            pid = slug(part)
            toc.append(("part", part, pid))
            parts_html.append(f'<section class="part-page" id="{pid}"><div class="part-label">{part.split(":")[0]}</div>'
                              f'<h1 class="part-title">{part.split(": ",1)[1]}</h1></section>')
        toc.append(("ch", f"Chapter {int(num)}: {title}", cid))
        bhtml = md_to_html(body)
        # collect section headings for TOC
        for m in re.finditer(r"<h2>(.*?)</h2>", bhtml):
            pass
        parts_html.append(
            f'<section class="chapter" id="{cid}" data-title="Chapter {int(num)} · {html.escape(title)}">'
            f'<div class="ch-open"><div class="ch-num">Chapter {int(num)}</div><h1 class="ch-title">{title}</h1></div>'
            f'{bhtml}</section>')
        if ans.strip():
            aid = f"ans{num}"
            answers_html.append(f'<h2 id="{aid}">Chapter {int(num)}: {title}</h2>' + md_to_html(ans))

    front = (ROOT / "front.html").read_text()
    intro = md_to_html((CH / "intro.md").read_text())
    howto = md_to_html(execute_chapter((CH / "howto.md").read_text(), log))

    BACK = [("glossary", "Glossary"), ("python_ref", "Python Quick Reference"),
            ("pandas_cheat", "Pandas Cheat Sheet"), ("checklists", "Checklists"),
            ("resources", "Further Learning Resources")]
    back_html = ""
    for slug_, title in BACK:
        body = md_to_html(execute_chapter((ROOT / "back" / f"{slug_}.md").read_text(), log))
        back_html += (f'<section class="back" id="{slug_}" data-title="{title}">'
                      f'<h1 class="fm-title">{title}</h1>{body}</section>')
        toc.append(("back", title, slug_))
    toc.append(("back", "Answer Key", "answer-key"))
    toc_html = "".join(
        f'<li class="toc-{k}"><a href="#{i}">{html.escape(t)}</a></li>' for k, t, i in toc)

    css = (ROOT / "style.css").read_text().replace("FONTDIR", str(ROOT / "fonts"))
    doc = f"""<!doctype html><html><head><meta charset="utf-8"><style>{css}</style>
<title>Learn Data Analytics with Python</title></head><body>
{front}
<section class="front toc"><h1 class="fm-title">Contents</h1>
<ul class="toc-list">
<li class="toc-front"><a href="#howto">How to Use This Book</a></li>
<li class="toc-front"><a href="#intro">Introduction: Welcome. You Can Do This.</a></li>
{toc_html}</ul></section>
<section class="front" id="howto"><h1 class="fm-title">How to Use This Book</h1>{howto}</section>
<section class="front" id="intro"><h1 class="fm-title">Introduction</h1>{intro}</section>
{''.join(parts_html)}
{back_html}
<section class="back" id="answer-key" data-title="Answer Key"><h1 class="fm-title">Answer Key</h1>
<p class="lead">Try every exercise yourself before you check these answers. For coding exercises, your code may look different and still be correct, as long as it gives the same result.</p>
{''.join(answers_html)}</section>
</body></html>"""
    (ROOT / "book.html").write_text(doc)
    out = ROOT / "Learn-Data-Analytics-with-Python.pdf"
    HTML(string=doc, base_url=str(ROOT)).write_pdf(out)
    errs = [l for l in log if l[0]]
    print(f"code blocks run: {len(log)}, raising errors (intended demos): {len(errs)}")
    for e in errs:
        print("  ERR demo:", e[1], "->", e[2])
    return out


if __name__ == "__main__":
    print(build())
