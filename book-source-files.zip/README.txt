Source files for "Learn Data Analytics with Python" (Saurabh Kumar).

chapters/*.md   Chapter text (Markdown). Code blocks followed by an empty ```output block are executed at build time.
back/*.md       Glossary, quick references, checklists, resources.
front.html      Cover, title page, copyright page.
style.css       Page design.
make_data.py    Regenerates every practice dataset (fixed random seeds).
build.py        Runs all code, inserts real outputs and charts, and builds the PDF.

To rebuild: pip install weasyprint markdown pygments pandas==2.2.3 matplotlib seaborn openpyxl
Fonts: place Inter and JetBrains Mono .ttf files in a fonts/ folder (both are free, SIL Open Font Licence).
Then: python make_data.py && python build.py
