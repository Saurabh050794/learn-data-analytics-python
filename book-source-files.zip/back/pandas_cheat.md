The Pandas, NumPy, and chart commands used most often in this book. `df` stands for any DataFrame.

## Setup and Loading

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("file.csv", parse_dates=["order_date"])
df = pd.read_excel("file.xlsx", sheet_name="Sheet1")
df.to_csv("clean.csv", index=False)
```

## First Look

| Command | Shows |
| --- | --- |
| `df.shape` | (rows, columns) |
| `df.head()`, `df.tail(3)` | First or last rows |
| `df.columns` | Column names |
| `df.info()` | Types and non-null counts |
| `df.describe()` | Summary statistics of number columns |
| `df.isna().sum()` | Missing values per column |
| `df.duplicated().sum()` | Number of duplicate rows |
| `df["col"].unique()`, `.nunique()` | Distinct values, and how many |
| `df["col"].value_counts()` | How often each value appears |

## Selecting and Filtering

```python
df["product"]                           # one column (a Series)
df[["product", "revenue"]]              # several columns
df.iloc[0], df.iloc[0:5]                # by position (end excluded)
df.loc[0:4, ["product", "revenue"]]     # by label (end included)
df[df["revenue"] > 1000]                # rows matching a condition
df[(df["region"] == "North") & (df["quantity"] >= 2)]   # and
df[(df["region"] == "North") | (df["region"] == "East")] # or
df[df["product"].isin(["Earbuds", "Charger"])]
df[df["order_date"].between("2025-10-01", "2025-12-31")]
df.sort_values("revenue", ascending=False)
df.nlargest(5, "revenue")
```

## Cleaning

```python
df = df.copy()
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")
df = df.rename(columns={"qty": "quantity"})
df = df.drop_duplicates()
df["region"] = df["region"].str.strip().str.title()
df["product"] = df["product"].replace({"Usb Cable": "USB Cable"})
df["unit_price"] = df["unit_price"].str.replace("₹", "").str.replace(",", "")
df["unit_price"] = pd.to_numeric(df["unit_price"])
df["order_date"] = pd.to_datetime(df["order_date"])
df["region"] = df["region"].fillna("Unknown")
df = df.dropna(subset=["unit_price"])
df.loc[df["discount"] > 1, "discount"] = df["discount"] / 100
df = df.reset_index(drop=True)
```

## New Columns

```python
df["revenue"] = df["quantity"] * df["unit_price"] * (1 - df["discount"])
df["month"] = df["order_date"].dt.month
df["weekday"] = df["order_date"].dt.day_name()
df["big_order"] = df["revenue"] > 5000
df["band"] = pd.cut(df["revenue"], bins=[0, 1000, 5000, 20000],
                    labels=["Small", "Medium", "Large"])
df["size"] = np.where(df["quantity"] >= 3, "Bulk", "Normal")
```

## Summarising and Grouping

```python
df["revenue"].sum(), df["revenue"].mean(), df["revenue"].median()
df["revenue"].agg(["sum", "mean", "min", "max"])
df.groupby("region")["revenue"].sum().sort_values(ascending=False)
df.groupby("product").agg(orders=("order_id", "count"),
                          revenue=("revenue", "sum"))
df.groupby(["region", "category"])["revenue"].sum().unstack()
df.pivot_table(index="region", columns="category",
               values="revenue", aggfunc="sum")
df.groupby("month")["revenue"].sum().pct_change()
```

## Combining Tables

```python
merged = orders.merge(customers, on="customer_id", how="left",
                      validate="many_to_one")
# how = "left", "right", "inner", or "outer"
# Always compare len(orders) and len(merged) afterwards.
```

## Statistics

```python
df["revenue"].std()
df["revenue"].quantile([0.25, 0.5, 0.75])
df["unit_price"].corr(df["revenue"])
df[["quantity", "unit_price", "revenue"]].corr()

q1, q3 = df["revenue"].quantile([0.25, 0.75])
iqr = q3 - q1
outliers = df[(df["revenue"] < q1 - 1.5 * iqr) | (df["revenue"] > q3 + 1.5 * iqr)]
```

## Charts

```python
plt.figure(figsize=(8, 4))
plt.bar(x, heights)                     # categories
plt.barh(labels, values)                # long labels
plt.plot(x, y, marker="o")              # trends over time
plt.hist(values, bins=20)               # spread
plt.scatter(x, y, alpha=0.5)            # relationships
sns.boxplot(data=df, x="category", y="revenue")
plt.title("Title that states the finding")
plt.xlabel("X label (units)")
plt.ylabel("Y label (units)")
plt.legend()
plt.savefig("chart.png", dpi=150, bbox_inches="tight")   # before show()
plt.show()
```
