Copy these checklists into the first text cell of any new notebook, and tick each item as you go.

## Data-Cleaning Checklist

| # | Step | Done? |
| --- | --- | --- |
| 1 | Keep the raw data untouched; work on `df.copy()` | ☐ |
| 2 | Standardise column names: lowercase, underscores, no extra spaces | ☐ |
| 3 | Remove exact duplicate rows; check that the ID column is unique | ☐ |
| 4 | Clean text: strip spaces, fix capital letters, merge spelling variants, and **check the result** | ☐ |
| 5 | Convert types: text to numbers, text to dates | ☐ |
| 6 | Find special codes such as 999, -1, or 0 that mean "unknown", and replace them with `NaN` | ☐ |
| 7 | Handle missing values: recover, fill, label as unknown, remove, or leave. **Write down why** | ☐ |
| 8 | Check minimums and maximums for impossible values; ask the data owner when unsure | ☐ |
| 9 | Verify with `info()`, `isna().sum()`, `nunique()`, and `describe()` | ☐ |
| 10 | Save the clean data to a **new** file; never overwrite the raw file | ☐ |

## Data-Analysis Workflow Checklist

| # | Step | Done? |
| --- | --- | --- |
| 1 | **Ask:** write the business questions in plain language | ☐ |
| 2 | For each question, note the **measure**, the **group**, and the **operation** | ☐ |
| 3 | **Collect:** describe the data source, size, period, and every column | ☐ |
| 4 | **Clean:** follow the data-cleaning checklist | ☐ |
| 5 | **Analyse:** answer each question with a number | ☐ |
| 6 | Choose the right summary: mean or median, count or total | ☐ |
| 7 | Check group sizes; flag small groups as less reliable | ☐ |
| 8 | Ask "what else is different between these groups?" before explaining a difference | ☐ |
| 9 | **Visualise:** one clear chart per key finding | ☐ |
| 10 | **Share:** findings, recommendations, and limitations | ☐ |

## Chart Checklist

| # | Check | Done? |
| --- | --- | --- |
| 1 | The chart type fits the question (see Chapter 12, Section 12.9) | ☐ |
| 2 | The title states the finding, or at least the topic and period | ☐ |
| 3 | Both axes are labelled, with units | ☐ |
| 4 | Large numbers are shown in readable units (for example ₹ thousand) | ☐ |
| 5 | Bar charts start at zero | ☐ |
| 6 | A legend appears whenever there is more than one series | ☐ |
| 7 | Labels do not overlap | ☐ |
| 8 | No 3D effects or unnecessary colours | ☐ |

## Project Completion Checklist

| # | Check | Done? |
| --- | --- | --- |
| 1 | The notebook has a clear name and a title cell with the business questions | ☐ |
| 2 | Each step has a short text cell explaining what and why | ☐ |
| 3 | All cleaning decisions are recorded | ☐ |
| 4 | Every question has a written answer with numbers | ☐ |
| 5 | Correlation is never described as causation | ☐ |
| 6 | The summary includes findings, recommendations, and limitations | ☐ |
| 7 | Fictional or practice data is labelled honestly | ☐ |
| 8 | Unused cells and experiments are deleted | ☐ |
| 9 | **Runtime → Restart session and run all** works without errors | ☐ |
| 10 | The project is on GitHub with a README (see Chapter 18) | ☐ |
