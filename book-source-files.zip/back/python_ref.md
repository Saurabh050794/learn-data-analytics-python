A one-page reminder of the Python covered in Chapters 3 to 6.

## Values and Variables

```python
quantity = 3                  # int: whole number
price = 1499.50               # float: decimal number
product = "Earbuds"           # str: text
in_stock = True               # bool: True or False
phone = None                  # None: no value

type(price)                   # check a value's type
int("42"), float("0.15"), str(250)   # type conversion
```

## Operators

| Arithmetic | Comparison | Logical |
| --- | --- | --- |
| `+  -  *  /` | `==` equal, `!=` not equal | `and` |
| `//` whole division, `%` remainder | `>  <  >=  <=` | `or` |
| `**` power | | `not` |

## Printing

```python
total = 1254300.5
print(f"Total: ₹{total:,.2f}")    # Total: ₹1,254,300.50
print(f"Share: {0.236:.1%}")       # Share: 23.6%
```

## Lists and Dictionaries

```python
sales = [1200, 980, 1430]
sales[0], sales[-1], sales[0:2]    # first, last, slice
sales.append(1675)
len(sales), sum(sales), max(sales), min(sales), sorted(sales)

item = {"name": "Earbuds", "price": 1499}
item["price"]                      # look up a value
item["stock"] = 42                 # add or change a key
item.get("discount")               # None if the key is missing
for key, value in item.items():
    print(key, value)
```

## Conditions and Loops

```python
score = 78
if score >= 75:
    grade = "A"
elif score >= 40:
    grade = "Pass"
else:
    grade = "Fail"

total = 0
for amount in [2400, 1150, 299]:
    total += amount

savings = 0
while savings < 20000:
    savings += 3500

for number in range(1, 4):         # 1, 2, 3
    print(number)
```

## Functions

```python
def calculate_revenue(quantity, unit_price, discount=0.0):
    """Return the revenue for one order, rounded to 2 decimals."""
    return round(quantity * unit_price * (1 - discount), 2)

calculate_revenue(2, 1499, 0.10)   # 2698.2
calculate_revenue(4, 199)          # uses the default discount
```

## Common Errors

| Error | Usual cause |
| --- | --- |
| `SyntaxError` | Missing quote, bracket, or colon |
| `IndentationError` | Code under `if`, `for`, or `def` not indented |
| `NameError` | Spelling mistake, or a cell not run yet |
| `TypeError` | Wrong type, such as text + number |
| `ValueError` | Right type, wrong value, such as `int("twelve")` |
| `IndexError` | List position does not exist |
| `KeyError` | Dictionary key or column name does not exist |
| `ZeroDivisionError` | Dividing by zero |
