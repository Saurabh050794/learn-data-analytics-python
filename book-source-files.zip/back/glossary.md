Plain-English meanings of the key terms used in this book. The chapter where each term is first explained is shown in brackets.

| Term | Meaning |
| --- | --- |
| **Aggregation** | Combining many values into one summary number, such as a total or an average (11) |
| **Argument** | A value you pass into a function when you call it (6) |
| **Array** | A NumPy grid of values, all of the same type, that supports fast calculations (7) |
| **Boolean** | A value that is either `True` or `False` (4) |
| **Boolean mask** | A collection of `True`/`False` values used to filter rows or elements (7) |
| **Categorical data** | Data that places records into groups, such as city or product category (2) |
| **Column** | One property recorded for every record in a table; also called a variable or field (2) |
| **Confounding variable** | A third factor linked to both of two measures, which can make them look related (13) |
| **Correlation** | A number from −1 to +1 showing how strongly two numeric columns move together in a straight line (13) |
| **CSV** | Comma-Separated Values: a plain-text table format (9) |
| **Data** | Recorded information about things, people, or events (1) |
| **Data analytics** | Collecting, cleaning, exploring, and studying data to answer questions and support decisions (1) |
| **Data cleaning** | Fixing errors and inconsistencies in data so it can be analysed correctly (10) |
| **Data type** | The kind of value, such as integer, float, string, or boolean (4) |
| **DataFrame** | A Pandas table of rows and columns (8) |
| **Dataset** | A collection of related data, usually arranged as a table (2) |
| **Debugging** | Finding and fixing mistakes in code (6) |
| **Dictionary** | A Python collection of key–value pairs (5) |
| **Duplicate** | A row that exactly repeats another row (2, 9) |
| **f-string** | A string starting with `f` that can include variables inside `{ }` (4) |
| **Float** | A number with a decimal point (4) |
| **Function** | A named, reusable block of code that does one job (6) |
| **Histogram** | A chart showing how many values fall into each range (bin) (12) |
| **Index** | The position number of a list item, or the row labels of a Pandas table (5, 8) |
| **Insight** | A useful finding from data that helps someone take action (1) |
| **Integer** | A whole number (4) |
| **IQR** | Interquartile range: Q3 minus Q1, the spread of the middle 50% of values (13) |
| **Key** | A label in a dictionary, or a column used to link two tables (5, 16) |
| **KPI** | Key Performance Indicator: a headline number showing how a business is doing (14) |
| **Library** | A ready-made toolbox of code written by others, such as Pandas (3) |
| **List** | An ordered Python collection written in square brackets (5) |
| **Loop** | Code that repeats a block of instructions (5) |
| **Mean** | The total divided by the number of values: the ordinary average (7, 13) |
| **Median** | The middle value when the values are sorted (7, 13) |
| **Merge** | Combining two tables by matching values in a shared key column (11) |
| **Method** | An action that belongs to a type of value, written after a dot, such as `.append()` (5) |
| **Missing value** | An empty cell; shown as `NaN` in Pandas (9) |
| **Mode** | The most common value (13) |
| **Notebook** | A document mixing code, results, and notes, such as a Colab file (3) |
| **Numerical data** | Numbers you can do maths with, such as price or quantity (2) |
| **Outlier** | A value unusually far from most other values (12, 13) |
| **Parameter** | A variable in a function's definition that receives an argument (6) |
| **Percentile** | The value below which a given percentage of the data falls (13) |
| **Pivot table** | A summary table with one variable down the side and another across the top (11) |
| **Row** | One record in a table, describing one thing (2) |
| **Series** | A single labelled column in Pandas (8) |
| **Standard deviation** | How far values typically are from the mean (7, 13) |
| **String** | Text, written inside quote marks (4) |
| **Traceback** | Python's error report, read from the last line up (6) |
| **Variable** | A name that stores a value in Python; or a column in a dataset (2, 4) |
| **Vectorisation** | Calculating on a whole array at once, without a loop (7) |
| **Visualisation** | Showing data as a picture, such as a chart (12) |
