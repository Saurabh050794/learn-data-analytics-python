These free resources are good next steps. Web addresses can change over time; if a link does not work, search for the resource name.

## Official Documentation

| Resource | What it is for | Address |
| --- | --- | --- |
| Python Tutorial | The official, beginner-friendly Python tutorial | docs.python.org/3/tutorial |
| Pandas User Guide | Detailed explanations of every Pandas feature | pandas.pydata.org/docs/user_guide |
| NumPy Documentation | Arrays and numerical functions | numpy.org/doc |
| Matplotlib Tutorials | Charts, styling, and layout | matplotlib.org/stable/tutorials |
| Seaborn Tutorial | Statistical charts | seaborn.pydata.org/tutorial.html |
| Google Colab | Your free notebook environment | colab.research.google.com |

!!! tip "Beginner Tip"
    Documentation can feel dense at first. Use it the way you use a dictionary: look up one function when you need it, such as "pandas groupby", rather than reading from start to finish.

## Practice Datasets

| Source | What you will find | Address |
| --- | --- | --- |
| Open Government Data Platform India | Official Indian datasets on agriculture, health, transport, and more | data.gov.in |
| UCI Machine Learning Repository | Classic datasets, including Online Retail (Chapter 17) | archive.ics.uci.edu |
| Kaggle Datasets | Thousands of community datasets; always check each dataset's licence | kaggle.com/datasets |
| This book's data | All practice files used in this book | github.com/Saurabh050794/learn-data-analytics-python |

!!! note "Check the Licence"
    Before using a dataset in a public portfolio, read its licence and credit the source. Licences such as CC BY 4.0 allow reuse with credit; some datasets do not allow redistribution at all.

## Next Skills

| Skill | Free place to start |
| --- | --- |
| SQL | SQLBolt (sqlbolt.com): short interactive lessons in the browser |
| Python and Pandas practice | Kaggle Learn (kaggle.com/learn): short free courses with exercises |
| Power BI | Microsoft Learn (learn.microsoft.com): free Power BI learning paths |
| Statistics | Khan Academy (khanacademy.org): Statistics and Probability course |

## Keep Practising

The best resource is regular practice on data you find interesting. Pick one public dataset each month, write three business questions, and answer them using the workflow checklist. After a year, you will have a portfolio of twelve analyses, and the confidence that comes with it.
