Every chapter follows the same simple pattern. First, you learn why the topic matters. Then you get a plain-English explanation and an everyday example. Then you run working code yourself and compare your result with the expected output. Finally, you practise with exercises. All answers are in the **Answer Key** at the back of the book.

## Reading the Code Examples

Code appears in a grey box with a teal edge. The box below it, marked **Output**, shows exactly what you should see when you run that code.

```python
print("Hello, Data Analyst!")
```

```output
```

Every output in this book was produced by actually running the code, using Python 3.12 and Pandas 2.2 (the versions long used by Google Colab). The only exception is one starter example in Chapter 17, which needs a file you download yourself and is clearly marked. The reference pages at the back were also tested. Your screen may look slightly different, especially for error messages and table styling, but the results should match.

When we show a mistake on purpose, the box is marked **Error message** in red. Do not worry when you see these. Learning to read errors is part of the skill.

## The Callout Boxes

!!! tip "Beginner Tip"
    A helpful shortcut or idea that makes learning easier.

!!! example "Real-Life Example"
    How the topic is used in an actual business or daily situation.

!!! mistake "Common Mistake"
    An error that many beginners make, and how to fix it.

!!! try "Try It Yourself"
    A small task to do right now, before you continue reading.

## Five Study Habits That Work

1. **Study a little every day.** 30–60 minutes daily works better than one long session per week.
2. **Type the code yourself.** Do not copy and paste. Typing helps you remember and helps you notice details.
3. **Do every exercise.** Try it first, then check the Answer Key.
4. **Change the examples.** After running an example, change one number or word and run it again.
5. **Keep notes.** Write new words and commands in your own notebook.
