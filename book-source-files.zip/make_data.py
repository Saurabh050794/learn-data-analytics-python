"""Generate the fictional datasets used in the book (fixed seed = reproducible)."""
import numpy as np, pandas as pd, pathlib

OUT = pathlib.Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)
rng = np.random.default_rng(42)

PRODUCTS = [  # product, category, unit_price
    ("Earbuds", "Audio", 1499), ("Bluetooth Speaker", "Audio", 2499),
    ("Smartwatch", "Wearables", 3999), ("Fitness Band", "Wearables", 1999),
    ("Power Bank", "Accessories", 999), ("USB Cable", "Accessories", 199),
    ("Phone Case", "Accessories", 349), ("Charger", "Accessories", 599),
]
P_WEIGHTS = np.array([18, 8, 9, 10, 15, 16, 14, 10], float); P_WEIGHTS /= P_WEIGHTS.sum()
REGIONS = ["North", "South", "East", "West"]; R_W = [0.32, 0.26, 0.18, 0.24]
MONTH_W = np.array([7, 6, 7, 7, 8, 7, 7, 8, 8, 11, 12, 12], float)

# ---- clean sales data (500 orders, year 2025) ----
fixed = [
    (1001, "2025-01-03", "Earbuds", "North", 2, 0.10),
    (1002, "2025-01-03", "Power Bank", "South", 1, 0.00),
    (1003, "2025-01-04", "Smartwatch", "West", 1, 0.15),
    (1004, "2025-01-05", "Earbuds", "East", 3, 0.05),
    (1005, "2025-01-05", "USB Cable", "North", 4, 0.00),
]
n = 500
days = pd.date_range("2025-01-06", "2025-12-31")
day_w = MONTH_W[days.month - 1]; day_w = day_w / day_w.sum()
dates = np.sort(rng.choice(days, size=n - len(fixed), p=day_w))
rows = []
lookup = {p: (c, u) for p, c, u in PRODUCTS}
for oid, d, p, r, q, disc in fixed:
    c, u = lookup[p]; rows.append([oid, d, p, c, r, q, u, disc])
for i, d in enumerate(dates):
    p, c, u = PRODUCTS[rng.choice(len(PRODUCTS), p=P_WEIGHTS)]
    q = int(rng.choice([1, 2, 3, 4, 5], p=[0.45, 0.28, 0.14, 0.09, 0.04]))
    if p in ("USB Cable", "Phone Case"): q += int(rng.choice([0, 1, 2], p=[.5, .3, .2]))
    disc = float(rng.choice([0, 0.05, 0.10, 0.15, 0.20], p=[0.42, 0.22, 0.18, 0.12, 0.06]))
    if pd.Timestamp(d).month in (10, 11) and rng.random() < 0.35: disc = 0.20  # festival sale
    rows.append([1006 + i, pd.Timestamp(d).strftime("%Y-%m-%d"), p, c,
                 str(rng.choice(REGIONS, p=R_W)), q, u, disc])
clean = pd.DataFrame(rows, columns=["order_id", "order_date", "product", "category",
                                    "region", "quantity", "unit_price", "discount"])
clean.to_csv(OUT / "sales_data_reference.csv", index=False)

# ---- messy raw version ----
raw = clean.copy()
raw["unit_price"] = raw["unit_price"].astype(str)
pick = lambda k, exclude=(): rng.choice([i for i in raw.index if i >= 5 and i not in exclude], k, replace=False)
used = set()
def take(k):
    idx = pick(k, used); used.update(idx); return idx
for i in take(14): raw.at[i, "unit_price"] = f"₹{int(clean.at[i, 'unit_price']):,}"
for i in take(7): raw.at[i, "unit_price"] = np.nan
for i, v in zip(take(18), ["north", "SOUTH", "East ", " West", "south", "NORTH", "west", "north ", "East",
                            "South ", "north", "WEST", "east", "North ", "south", "West ", "NORTH", "east "]):
    raw.at[i, "region"] = v.replace("East", "east ") if v == "East" else v
for i in take(5): raw.at[i, "region"] = np.nan
for i in take(10): raw.at[i, "product"] = raw.at[i, "product"].lower() if rng.random() < .6 else raw.at[i, "product"] + " "
for i in take(3): raw.at[i, "quantity"] = -raw.at[i, "quantity"]
for i in take(2): raw.at[i, "discount"] = 15.0
dups = raw.loc[take(6)]
raw = pd.concat([raw, dups]).sort_values("order_id", kind="stable").reset_index(drop=True)
raw.columns = ["Order ID", "Order Date", "Product ", "Category", "Region", "Qty", "Unit Price", "Discount"]
raw.to_csv(OUT / "sales_data_raw.csv", index=False)

# ---- small Excel file: regional targets ----
targets = pd.DataFrame({"region": REGIONS, "annual_target": [380000, 300000, 220000, 280000],
                        "manager": ["Ankit Verma", "Divya Nair", "Sourav Das", "Pooja Shah"]})
with pd.ExcelWriter(OUT / "region_targets.xlsx") as xw:
    targets.to_excel(xw, sheet_name="Targets", index=False)

print(clean.shape, raw.shape)
print(raw.head(8).to_string())

# ---- student performance data (Chapter 15) ----
srng = np.random.default_rng(2024)
n_s = 200
internet = srng.random(n_s) < 0.7
study = np.clip(np.where(internet, srng.normal(9.5, 3.2, n_s), srng.normal(6.5, 3.0, n_s)), 0, 20)
study = np.round(study * 2) / 2                                   # nearest half hour
attendance = np.clip(srng.normal(82, 9, n_s), 45, 100).round()
ability = srng.normal(0, 8, n_s)
def score(base, k_study, k_att, noise):
    raw = base + k_study * study + k_att * attendance + ability + srng.normal(0, noise, n_s)
    return np.clip(raw, 0, 100).round().astype(int)
math = score(-2, 2.6, 0.45, 8)
science = score(4, 2.2, 0.42, 8)
english = score(18, 1.2, 0.38, 7)
students = pd.DataFrame({
    "student_id": [f"S{i:03d}" for i in range(1, n_s + 1)],
    "section": srng.choice(["A", "B", "C"], n_s),
    "study_hours_per_week": study,
    "attendance_percent": attendance,
    "math_score": math, "science_score": science, "english_score": english,
    "internet_access": np.where(internet, "Yes", "No"),
})
students.loc[srng.choice(n_s, 5, replace=False), "study_hours_per_week"] = np.nan
students.loc[srng.choice(n_s, 3, replace=False), "attendance_percent"] = np.nan
students.to_csv(OUT / "students.csv", index=False)
print(students.describe().round(1))
print(students.groupby("internet_access")[["study_hours_per_week", "math_score"]].mean().round(1))
print(students[["study_hours_per_week","attendance_percent","math_score","science_score","english_score"]].corr().round(2))

# ---- e-commerce customers + orders (Chapter 16) ----
erng = np.random.default_rng(16)
n_c = 300
channels = erng.choice(["Instagram", "Google Ads", "Referral", "Organic"], n_c, p=[0.34, 0.26, 0.15, 0.25])
cities = erng.choice(["Lucknow", "Kanpur", "Bareilly", "Agra", "Varanasi"], n_c, p=[0.3, 0.22, 0.16, 0.17, 0.15])
signup = pd.to_datetime("2025-01-01") + pd.to_timedelta(erng.integers(0, 300, n_c), unit="D")
customers_df = pd.DataFrame({"customer_id": [f"C{i:04d}" for i in range(1, n_c + 1)],
                             "city": cities, "signup_date": signup.strftime("%Y-%m-%d"),
                             "channel": channels})
# order-frequency depends on channel (referral customers come back more)
lam = pd.Series(channels).map({"Instagram": 2.0, "Google Ads": 2.3, "Referral": 4.2, "Organic": 3.2}).values
n_orders = erng.poisson(lam)
n_orders[erng.random(n_c) < 0.08] = 0                      # some never ordered
CATS = {"Kurtis": (899, 0.30), "T-Shirts": (499, 0.25), "Jeans": (1299, 0.18),
        "Sarees": (2199, 0.12), "Footwear": (1099, 0.15)}
rows = []
oid = 50001
for cid, sd, k in zip(customers_df["customer_id"], signup, n_orders):
    for _ in range(k):
        cat = erng.choice(list(CATS), p=[v[1] for v in CATS.values()])
        items = int(erng.choice([1, 2, 3, 4], p=[0.55, 0.28, 0.12, 0.05]))
        price = CATS[cat][0] * erng.uniform(0.85, 1.25)
        d = sd + pd.Timedelta(days=int(erng.integers(0, max(2, (pd.Timestamp("2025-12-31") - sd).days))))
        rows.append([d, cid, cat, items, round(price * items, -1),
                     erng.choice(["UPI", "Card", "COD"], p=[0.55, 0.2, 0.25])])
orders_df = pd.DataFrame(rows, columns=["order_date", "customer_id", "category", "items",
                                        "order_value", "payment_method"]).sort_values("order_date")
orders_df.insert(0, "order_id", range(50001, 50001 + len(orders_df)))
orders_df["order_date"] = orders_df["order_date"].dt.strftime("%Y-%m-%d")
customers_df.to_csv(OUT / "customers.csv", index=False)
orders_df.to_csv(OUT / "orders.csv", index=False)
print("customers", customers_df.shape, "orders", orders_df.shape)

# ---- food delivery capstone (Chapter 17) ----
frng = np.random.default_rng(1717)
n_f = 1200
zones = ["Civil Lines", "Gomti Nagar", "Aliganj", "Hazratganj", "Indira Nagar"]
zone = frng.choice(zones, n_f, p=[0.18, 0.27, 0.17, 0.2, 0.18])
cuisine = frng.choice(["North Indian", "Chinese", "Biryani", "South Indian", "Pizza", "Desserts"], n_f,
                      p=[0.27, 0.18, 0.2, 0.12, 0.15, 0.08])
day = pd.to_datetime("2025-07-01") + pd.to_timedelta(frng.integers(0, 92, n_f), unit="D")
hour = frng.choice(range(10, 24), n_f, p=np.array([1, 2, 6, 9, 7, 3, 2, 3, 5, 9, 12, 11, 7, 3], float) / 80)
minute = frng.integers(0, 60, n_f)
ts = day + pd.to_timedelta(hour, unit="h") + pd.to_timedelta(minute, unit="m")
base_val = pd.Series(cuisine).map({"North Indian": 420, "Chinese": 360, "Biryani": 380,
                                   "South Indian": 260, "Pizza": 520, "Desserts": 240}).values
items = frng.choice([1, 2, 3, 4, 5], n_f, p=[0.3, 0.33, 0.2, 0.12, 0.05])
value = (base_val * (0.7 + 0.3 * items) * frng.uniform(0.85, 1.2, n_f)).round()
zone_delay = pd.Series(zone).map({"Civil Lines": 0, "Gomti Nagar": 4, "Aliganj": 2,
                                  "Hazratganj": 7, "Indira Nagar": 3}).values
peak = np.isin(hour, [13, 14, 20, 21, 22]).astype(int) * 6
delivery = np.clip(frng.normal(28, 6, n_f) + zone_delay + peak, 12, 75).round()
rating_raw = 5.2 - 0.045 * (delivery - 25) + frng.normal(0, 0.6, n_f)
rating = np.clip(rating_raw.round(), 1, 5)
food = pd.DataFrame({"order_id": [f"FD{i:05d}" for i in range(1, n_f + 1)],
                     "order_time": ts.strftime("%Y-%m-%d %H:%M"), "zone": zone, "cuisine": cuisine,
                     "items": items, "order_value": value, "delivery_minutes": delivery,
                     "rating": rating,
                     "payment_method": frng.choice(["UPI", "Card", "Cash"], n_f, p=[0.6, 0.18, 0.22]),
                     "customer_type": frng.choice(["New", "Returning"], n_f, p=[0.3, 0.7])})
food = food.sort_values("order_time").reset_index(drop=True)
food["order_id"] = [f"FD{i:05d}" for i in range(1, n_f + 1)]
# messiness
food.loc[frng.choice(n_f, 260, replace=False), "rating"] = np.nan          # many customers don't rate
food.loc[frng.choice(n_f, 6, replace=False), "delivery_minutes"] = 999     # system placeholder
idx = frng.choice(n_f, 30, replace=False)
food.loc[idx, "zone"] = [z.lower() if i % 2 else z.upper() for i, z in enumerate(food.loc[idx, "zone"])]
idx2 = frng.choice(n_f, 12, replace=False)
food.loc[idx2, "cuisine"] = food.loc[idx2, "cuisine"].str.replace("South Indian", "South-Indian").str.replace("North Indian", "North indian")
food = pd.concat([food, food.loc[frng.choice(n_f, 8, replace=False)]]).sort_values("order_time").reset_index(drop=True)
food.to_csv(OUT / "food_delivery_orders.csv", index=False)
print("food", food.shape)
