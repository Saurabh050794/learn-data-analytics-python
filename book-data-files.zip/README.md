# Learn Data Analytics with Python — Practice Data

Practice files for the book *Learn Data Analytics with Python: From Zero to Real-World Projects* by Saurabh Kumar.

All datasets are **fictional** and were created for teaching. Any resemblance to real businesses or people is coincidental.

| File | Used in | Description |
| --- | --- | --- |
| `data/sales_data_raw.csv` | Chapters 9, 10, 14 | 2025 orders from a fictional electronics store, with deliberate data-quality problems |
| `data/sales_data_clean.csv` | Chapters 11–14 | The same data after the cleaning steps in Chapter 10 (497 orders, with a revenue column) |
| `data/region_targets.xlsx` | Chapters 9, 11, 14 | Yearly sales target and manager for each region (sheet: Targets) |
| `data/students.csv` | Chapter 15 | 200 students' study hours, attendance, marks, and internet access |
| `data/customers.csv` | Chapter 16 | 300 customers of an online fashion store: city, sign-up date, marketing channel |
| `data/orders.csv` | Chapter 16 | 812 orders from those customers in 2025 |
| `data/food_delivery_orders.csv` | Chapter 17 | 1,208 raw cloud-kitchen orders (Jul–Sep 2025), with deliberate data-quality problems |

Load a file in Google Colab:

```python
import pandas as pd
DATA_URL = "https://raw.githubusercontent.com/Saurabh050794/learn-data-analytics-python/main/data/"
sales = pd.read_csv(DATA_URL + "sales_data_clean.csv")
```
